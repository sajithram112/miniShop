Navigate to Backend - folder
Make sure Node js is installed
Download PG Sql and set up and password
run pg admin app
npm install

migrate table - only first time
node migration/tableMigration.js

migrate - datas - only first time
node migration/dataMigration.js

now you are set 
Npm start

you can see server listeming to port - server connected
postgresql connected successfully - db connected